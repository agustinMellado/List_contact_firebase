package com.example.firestore_conexion_recycleview

data class Productos(
    var nombre: String? = null,
    var imagen: String? = null,
    var precio: String? = null,
    var descripcion: String? = null,
    var oferta: String? = null
)
